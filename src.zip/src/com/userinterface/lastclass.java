package com.userinterface;

import javafx.fxml.FXML;
import javafx.scene.control.Label;


public class lastclass {
    @FXML
    Label org;
    public void ini(String o){
        org.setText(o);
    }
}
